import React from 'react';
import { Line } from '@ant-design/charts';

const Compo =({but1 , data})=>{

  const config = {
    data,
    title: {
      visible: true,
      text: '텍스트 부분',
    },
    xField: 'numx',
    yField: 'numy',
  };


  return(
    <div>
        <button onClick={but1}>버튼</button>

        {data && <Line {...config} />}
        {data && console.log(data)}
    </div>
  );
}

export default Compo;
