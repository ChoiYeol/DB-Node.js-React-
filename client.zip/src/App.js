import React from 'react';
import Contain from './container/Contain';

const App=()=> {

  return (
    <div>
      <Contain />
    </div>
  );
}
export default App;
