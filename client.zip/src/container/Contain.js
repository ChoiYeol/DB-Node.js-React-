import React , {useState} from 'react';
import axios from 'axios';
import Compo from '../component/Compo';

const Contain=()=>{
  
  const [data, setData]= useState(null);

  const but1 = async ()=>{
   const response = await axios.get('/number').then(res=>{
    setData(res.data);
   });
 }

  return (
    <div>
        <Compo but1={but1} data={data} />
    </div>
  );
}

export default Contain;
