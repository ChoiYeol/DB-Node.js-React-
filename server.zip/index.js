const Koa = require('koa');
const Router = require('koa-router');
const app =new Koa();
const router = new Router();
const bodyParser = require('koa-bodyparser');
const port = 5500;

const {Pool} = require('pg');
let pool = new Pool({
  user: 'yeol',
  password:'038100',
  host:  '192.168.219.140',
  port: 5432,
  database:'tunneldata',
});

const postgres = async (sql)=>{
  let client = await pool.connect();
  let result = await client.query(sql);
  client.release();
  return result.rows;
}

const testFunction = async ctx => {
  let sql = 'select numx, numy from test';
  let sqlMax = 'select numx, numy from test where  numx = (select MAX(numx) from test) ';
  ctx.body= await postgres(sql);

};

router.get('/number', testFunction);


app.use(router.routes()).use(router.allowedMethods());

app.listen(port, ()=>{
  console.log(port);
});
